document.addEventListener('DOMContentLoaded', () => {

    // Tab Navigation
    const navItems = document.querySelectorAll('.nav-item');
    const tabContents = document.querySelectorAll('.tab-content');

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            // Remove active classes
            navItems.forEach(nav => nav.classList.remove('active'));
            tabContents.forEach(tab => tab.classList.remove('active'));
            
            // Add active to clicked and matching tab
            item.classList.add('active');
            const tabId = item.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });

    // -------- TAB 1: CITIZEN ANALYSIS --------
    const citizenUpload = document.getElementById('citizen-upload');
    const citizenFile = document.getElementById('citizen-file');
    const analyzeBtn = document.getElementById('start-analysis-btn');
    const previewContainer = document.getElementById('preview-container');
    const previewImage = document.getElementById('preview-image');
    
    // Upload interaction
    citizenUpload.addEventListener('click', () => {
        // Normally this would trigger input click: citizenFile.click();
        // Since it's an MVP demo, we will bypass actual file explorer for smooth demo
        // and just load the bundled problem.png immediately.
        simulateCitizenUpload();
    });

    function simulateCitizenUpload() {
        citizenUpload.classList.add('hidden');
        previewContainer.classList.remove('hidden');
        previewImage.src = 'assets/problem.png'; // Load our dummy image
        analyzeBtn.disabled = false;
        
        logToConsole("İstifadəçi IP qeydə alındı. Yeni vizual məlumat qəbul edildi.", "system");
        logToConsole("Zəhmət olmasa təhlil üçün 'AI Analizini Başlat' düyməsini sıxın.", "system");
    }

    // AI Analysis simulation
    analyzeBtn.addEventListener('click', () => {
        analyzeBtn.disabled = true;
        previewContainer.classList.add('scanning');
        document.getElementById('structured-results').classList.remove('hidden');
        
        // Reset old values
        document.querySelector('.description-val').innerHTML = '<span style="color:var(--text-muted)">Təhlil edilir...</span>';
        document.querySelector('.category-val').textContent = '...';
        document.querySelector('.priority-val').textContent = '...';
        document.querySelector('.location-val').textContent = '...';
        document.getElementById('ai-logs').innerHTML = ''; // clear logs

        // Simulation sequence
        simulateAISequence();
    });

    function logToConsole(msg, type = 'system') {
        const consoleLog = document.getElementById('ai-logs');
        
        let iconHtml = '';
        let colorClass = '';
        
        if (type === 'system') {
            iconHtml = '<ion-icon name="information-circle-outline"></ion-icon>';
            colorClass = 'var(--text-muted)';
        } else if (type === 'active') {
            iconHtml = '<ion-icon name="sync-outline" style="animation: rotate 2s linear infinite;"></ion-icon>';
            colorClass = 'var(--primary)';
        } else if (type === 'success') {
            iconHtml = '<ion-icon name="checkmark-circle"></ion-icon>';
            colorClass = 'var(--success)';
        }

        const el = document.createElement('div');
        el.className = 'ai-step';
        el.style.cssText = `display: flex; align-items: center; gap: 8px; color: ${colorClass}; font-size: 13px; padding: 10px; background: rgba(0,0,0,0.2); border-radius: 8px; margin-bottom: 6px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); border: 1px solid rgba(255,255,255,0.02);`;
        
        el.innerHTML = `<span style="font-size: 18px; display: flex;">${iconHtml}</span> <span>${msg}</span>`;
        consoleLog.appendChild(el);
        consoleLog.scrollTop = consoleLog.scrollHeight;
    }

    async function simulateAISequence() {
        logToConsole("Süni İntellekt şəkli təhlil etməyə başlayır...", "active");
        
        await delay(1500);
        
        // Add random scanning boxes safely inside preview
        const overlay = document.querySelector('.ai-overlay-boxes');
        overlay.innerHTML = `
            <div class="detection-box" style="top: 30%; left: 20%; width: 50%; height: 40%;">
                <div class="detection-label">Çuxur 98%</div>
            </div>
            <div class="detection-box" style="top: 10%; left: 70%; width: 20%; height: 20%; border-color: yellow">
                <div class="detection-label" style="background: yellow; color: black;">Asfalt toxuması</div>
            </div>
        `;
        
        logToConsole("Şəkildəki əsas problem vizual olaraq tapıldı: Çuxur, Zədələnmiş Asfalt", "success");
        
        await delay(1200);
        logToConsole("Tapılan problemə uyğun izahlı mətn (təsvir) yazılır...", "active");
        
        await delay(1500);
        document.querySelector('.description-val').textContent = "Asfalt örtüyündə dərin və irihəcmli çuxur yaranıb. Nəqliyyatın hərəkəti üçün ciddi təhlükə yaradır.";
        logToConsole("Görüntünün yazılı izahatı uğurla yaradıldı.", "success");

        await delay(1000);
        logToConsole("Müraciətin hansı dövlət qurumuna/kateqoriyaya aid olduğu axtarılır...", "active");
        
        await delay(1000);
        const catVal = document.querySelector('.category-val');
        catVal.textContent = "İnfrastruktur / Yol və Nəqliyyat";
        catVal.style.color = "#60a5fa"; // blueish
        
        await delay(1000);
        logToConsole("Problemin nə dərəcədə təcili (təhlükəli) olduğu hesablanır...", "active");
        
        await delay(1000);
        const priVal = document.querySelector('.priority-val');
        priVal.innerHTML = "<span style='background: rgba(239, 68, 68, 0.2); padding: 2px 6px; border-radius: 4px; border: 1px solid rgba(239, 68, 68, 0.3); color: #fca5a5;'>YÜKSƏK (Təcili)</span>";

        await delay(800);
        document.querySelector('.location-val').textContent = "40.3776° N, 49.8920° E (Şəklin Exif GPS məlumatı)";
        logToConsole("Tamamlandı! Bütün nəticələr cəmlənərək təqdim edilir.", "success");
        
        // Dynamically update the forward button based on category
        const fwdBtn = document.getElementById('forward-agency-btn');
        fwdBtn.disabled = false;
        fwdBtn.innerHTML = '<ion-icon name="paper-plane-outline"></ion-icon> Avtomobil Yolları Dövlət Agentliyinə Yönləndir';
        
        previewContainer.classList.remove('scanning');
    }

    // Forward to Agency (without switching tabs)
    document.getElementById('forward-agency-btn').addEventListener('click', function() {
        this.innerHTML = '<ion-icon name="checkmark-done-outline"></ion-icon> Müraciət Uğurla AAYDA-ya Yönləndirildi';
        this.classList.remove('btn-success');
        this.className = 'btn btn-primary'; // change style
        this.style.background = 'var(--success)';
        this.disabled = true;
    });

    // Toggle API visual view and run animation
    document.getElementById('view-api-btn').addEventListener('click', async () => {
        const apiView = document.getElementById('api-json-view');
        const isHidden = apiView.classList.contains('hidden');
        
        if(isHidden) {
            apiView.classList.remove('hidden');
            
            // Reset state
            const flowLine = document.getElementById('api-flow-line');
            const serverNode = document.getElementById('server-node');
            const serverText = document.getElementById('server-node-text');
            const dataSummary = document.getElementById('api-data-summary');
            
            flowLine.classList.remove('success');
            flowLine.classList.remove('animating');
            serverNode.classList.remove('success');
            serverText.textContent = "Gözləyir...";
            dataSummary.classList.add('hidden');
            
            // Start sending animation
            flowLine.classList.add('animating');
            
            await delay(2000); // Wait 2 seconds for "sending"
            
            // Success
            flowLine.classList.remove('animating');
            flowLine.classList.add('success');
            serverNode.classList.add('success');
            serverText.innerHTML = "<strong>ASAN Bazasında Qeydə Alındı</strong>";
            
            await delay(400); // small delay before showing data
            dataSummary.classList.remove('hidden');
        } else {
            apiView.classList.add('hidden');
        }
    });


    // -------- TAB 2: AGENCY VALIDATION --------
    const agencyUpload = document.getElementById('agency-upload');
    const newImg = document.getElementById('tab2-new-img');
    const verifyBtn = document.getElementById('verify-btn');
    
    // Uğurlu ssenari
    document.getElementById('demo-correct-btn').addEventListener('click', () => {
        setupValidationDemo('assets/fixed.png', true);
    });

    // Uğursuz ssenari
    document.getElementById('demo-fail-btn').addEventListener('click', () => {
        setupValidationDemo('assets/problem.png', false); // Using the same problem image to simulate "nothing fixed"
    });

    function setupValidationDemo(imgSrc, isCorrect) {
        document.getElementById('agency-upload').classList.add('hidden');
        document.getElementById('new-img-badge').classList.remove('hidden');
        newImg.classList.remove('hidden');
        newImg.src = imgSrc;
        verifyBtn.disabled = false;
        
        // Save the scenario state
        verifyBtn.dataset.isCorrect = isCorrect;
    }

    verifyBtn.addEventListener('click', async () => {
        verifyBtn.disabled = true;
        verifyBtn.innerHTML = '<ion-icon name="sync-outline" style="animation: rotate 2s linear infinite;"></ion-icon> Yoxlanılır...';
        
        document.getElementById('val-placeholder').classList.add('hidden');
        document.getElementById('verification-stats').classList.remove('hidden');
        
        // Reset styles for both scenarios
        const decisionBox = document.getElementById('final-decision-box');
        const gpsStatus = document.getElementById('gps-match-status');
        const objStatus = document.getElementById('obj-match-status');
        const verdictTitle = document.getElementById('ai-verdict-title');
        
        gpsStatus.textContent = "Analiz Dərinliyi: EXIF Metadatalar oxunur...";
        gpsStatus.style.color = "var(--text-main)";
        objStatus.textContent = "Obyekt qradiyenti incələnir...";
        objStatus.style.color = "var(--text-main)";
        verdictTitle.textContent = "Hesablanır...";
        verdictTitle.style.color = "var(--text-main)";
        
        await delay(2000);
        
        verifyBtn.innerHTML = '<ion-icon name="checkmark-done-outline"></ion-icon> Yoxlama Bitdi';
        
        const isCorrect = verifyBtn.dataset.isCorrect === 'true';
        
        if(isCorrect) {
            // UĞURLU SSENARİ
            decisionBox.style.background = 'rgba(16, 185, 129, 0.15)';
            decisionBox.style.borderColor = 'rgba(16, 185, 129, 0.3)';
            decisionBox.style.color = 'var(--success)';
            decisionBox.innerHTML = '<ion-icon name="checkmark-circle"></ion-icon> Müraciət Təsdiqlənib Bağlanıla Bilər';
            verdictTitle.textContent = "UYĞUNLUQ TƏSDİQLƏNDİ";
            verdictTitle.style.color = "var(--success)";
            
            gpsStatus.textContent = "Təsdiqləndi (98% - Koordinatlar Eynidir)";
            gpsStatus.style.color = "var(--success)";
            objStatus.textContent = "Müsbət - Çuxur örtülüb, yeni asfalt təbəqəsi";
            objStatus.style.color = "var(--success)";

            animateProgress(95, true);
            
            // Show Employee Success Modal directly
            setTimeout(() => {
                document.getElementById('employee-success-modal').classList.remove('hidden');
            }, 500); // Popup right after animation starts
        } else {
            // UĞURSUZ SSENARİ (SAXTAKARLIQ)
            decisionBox.style.background = 'rgba(239, 68, 68, 0.2)';
            decisionBox.style.borderColor = 'rgba(239, 68, 68, 0.5)';
            decisionBox.style.color = 'var(--danger)';
            decisionBox.innerHTML = '<ion-icon name="alert-circle-outline"></ion-icon> SAXTAKARLIQ AŞKARLANDI! (Xəbərdarlıq)';
            verdictTitle.textContent = "UYĞUNSUZLUQ TƏYİN EDİLDİ";
            verdictTitle.style.color = "var(--danger)";
            
            gpsStatus.textContent = "Təsdiqləndi (98% - Lokasiya Eynidir)"; 
            gpsStatus.style.color = "var(--success)";
            objStatus.textContent = "MƏNFİ - Heç bir yol təmiri/dəyişiklik aşkarlanmadı";
            objStatus.style.color = "var(--danger)";

            animateProgress(12, false);
            
            // Show Employee Warning Modal directly
            setTimeout(() => {
                document.getElementById('employee-warning-modal').classList.remove('hidden');
            }, 500); // Popup right after animation starts
        }
    });

    function animateProgress(targetValue, isCorrect) {
        let current = 0;
        const speed = 15;
        const numberEl = document.getElementById('match-percent');
        const circle = document.getElementById('progress-circle');
        
        // 220 is circumference for r=35
        const totalOffset = 220;
        circle.style.strokeDasharray = totalOffset;
        
        const interval = setInterval(() => {
            current += 1;
            // Handle targetValue lower than current
            if (!isCorrect && current > targetValue) {
                current = targetValue;
            }
            
            numberEl.innerHTML = `${current}<span style="font-size: 12px;">%</span>`;
            
            const offset = (totalOffset - (current / 100) * totalOffset);
            circle.style.strokeDashoffset = offset;
            
            if (current >= targetValue) {
                clearInterval(interval);
                if (isCorrect) {
                    circle.style.stroke = 'var(--success)';
                } else {
                    circle.style.stroke = 'var(--danger)';
                }
            }
        }, speed);
    }

    // Utils
    function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

});
